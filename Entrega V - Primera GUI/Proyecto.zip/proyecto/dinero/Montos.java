package pruebas;

public class Montos {

	public Montos(int montos) {
		super();
		Monto = montos;
	}

	int Monto;

	public int getMontos() {
		return Monto;
	}

	public void setMontos(int montos) {
		Monto = montos;
	}
}