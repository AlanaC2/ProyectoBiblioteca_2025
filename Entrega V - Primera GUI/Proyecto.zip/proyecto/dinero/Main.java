package pruebas;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main extends JFrame {
    private static final long serialVersionUID = 1L;
    Logica gestor = new Logica();
    DefaultTableModel modelo = new DefaultTableModel();
    public Main(){
        this.setTitle("Ventana DINERO");
        this.setSize(700, 400);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.getContentPane().setBackground(Colores.gris);
        modelo.addColumn("Fecha");
        modelo.addColumn("Monto");
        JTable tabla = new JTable(modelo);
        tabla.setBackground(Color.WHITE);
        tabla.setForeground(Color.BLACK);
        tabla.setFont(new Font("SansSerif", Font.PLAIN, 15));
        tabla.setRowHeight(30);
        tabla.getTableHeader().setBackground(Color.WHITE);
        tabla.getTableHeader().setForeground(Color.BLACK);
        tabla.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 15));
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        JPanel panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.setOpaque(false);
        JPanel panelIzquierda = new JPanel(new BorderLayout());
        panelIzquierda.setOpaque(false);
        panelIzquierda.add(scroll, BorderLayout.CENTER);
        JPanel panelDerecha = new JPanel();
        panelDerecha.setLayout(new BoxLayout(panelDerecha, BoxLayout.Y_AXIS));
        panelDerecha.setOpaque(false);
        panelDerecha.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        JLabel lblTitulo = new JLabel("Dinero de la fotocopia");
        lblTitulo.setForeground(Colores.marron);
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 16));
        lblTitulo.setAlignmentX(Component.LEFT_ALIGNMENT);
        panelDerecha.add(lblTitulo);
        panelDerecha.add(Box.createRigidArea(new Dimension(0, 10)));
        JPanel panelMonto = new JPanel();
        panelMonto.setLayout(new BoxLayout(panelMonto, BoxLayout.X_AXIS));
        panelMonto.setOpaque(false);
        JPanel panelCampo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(Color.BLACK);
                g.drawLine(30, getHeight() - 8, getWidth() - 10, getHeight() - 8);
            }
        };
        panelCampo.setLayout(new BoxLayout(panelCampo, BoxLayout.X_AXIS));
        panelCampo.setBackground(Color.WHITE);
        panelCampo.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        panelCampo.setMaximumSize(new Dimension(180, 35));
        panelCampo.setAlignmentY(Component.CENTER_ALIGNMENT);
        JLabel lblPeso = new JLabel("$");
        lblPeso.setFont(new Font("SansSerif", Font.BOLD, 18));
        lblPeso.setForeground(Color.BLACK);
        JTextField txtMonto = new JTextField();
        txtMonto.setBorder(null);
        txtMonto.setFont(new Font("SansSerif", Font.PLAIN, 16));
        txtMonto.setBackground(Color.WHITE);
        txtMonto.setForeground(Color.BLACK);
        panelCampo.add(lblPeso);
        panelCampo.add(Box.createRigidArea(new Dimension(5, 0)));
        panelCampo.add(txtMonto);
        JButton btnCargar = new JButton("Cargar");
        btnCargar.setBackground(new Color(20, 30, 80));
        btnCargar.setForeground(Color.WHITE);
        btnCargar.setFont(new Font("SansSerif", Font.BOLD, 15));
        btnCargar.setFocusPainted(false);
        btnCargar.setBorder(BorderFactory.createEmptyBorder(8, 25, 8, 25));
        btnCargar.setAlignmentY(Component.CENTER_ALIGNMENT);
        panelMonto.add(panelCampo);
        panelMonto.add(Box.createRigidArea(new Dimension(15, 0)));
        panelMonto.add(btnCargar);
        panelMonto.setAlignmentX(Component.LEFT_ALIGNMENT);
        panelDerecha.add(panelMonto);
        panelDerecha.add(Box.createRigidArea(new Dimension(0, 20)));
        JPanel panelFecha = new JPanel();
        panelFecha.setBackground(Color.WHITE);
        panelFecha.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panelFecha.setLayout(new BoxLayout(panelFecha, BoxLayout.Y_AXIS));
        panelFecha.setMaximumSize(new Dimension(300, 50));
        panelFecha.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel lblFecha = new JLabel("Fecha Actual");
        lblFecha.setForeground(Colores.marron);
        lblFecha.setFont(new Font("SansSerif", Font.BOLD, 16));
        panelFecha.add(lblFecha);
        panelDerecha.add(panelFecha);
        panelDerecha.add(Box.createVerticalGlue());
        panelPrincipal.add(panelIzquierda, BorderLayout.CENTER);
        panelPrincipal.add(panelDerecha, BorderLayout.EAST);
        this.setContentPane(panelPrincipal);
        
        btnCargar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int monto = Integer.parseInt(txtMonto.getText());
                    Logica.arreglo.add(new Montos(monto));
                    modelo.addRow(new Object[]{"", monto});
                    txtMonto.setText("");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(Main.this, "ingrese un numero valido!");
                }
            }
        });
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Main ventana = new Main();
            ventana.setVisible(true);
        });
    }
}