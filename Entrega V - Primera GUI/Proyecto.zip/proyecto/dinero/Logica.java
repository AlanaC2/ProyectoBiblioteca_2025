package pruebas;

import java.util.ArrayList;

import javax.swing.table.DefaultTableModel;

public class Logica {
	static ArrayList<Montos> arreglo = new ArrayList<>();

	public void mostrarAlta() {
		vtnAlta vtnA = new vtnAlta(null);
		vtnA.setVisible(true);
		
		
	}
	
    public void mostrarAlta(DefaultTableModel modelo) {
        vtnAlta vtnA = new vtnAlta(modelo);
        vtnA.setVisible(true);
    }
}