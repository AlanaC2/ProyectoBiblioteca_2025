package pruebas;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class vtnAlta extends JFrame {
    private DefaultTableModel modelo;

    public vtnAlta(DefaultTableModel modelo) {
        this.modelo = modelo;
        JFrame aviso = new JFrame();
        this.setLayout(new FlowLayout());
        this.getContentPane().setBackground(Colores.gris);
        this.setSize(350, 200);
        this.setLocationRelativeTo(null); 
        Logica gestor = new Logica();

        JLabel lblMonto = new JLabel("Monto : ");
        lblMonto.setForeground(Colores.verdeOcuro);
        lblMonto.setFont(new Font("SansSerif", Font.BOLD, 16));

        JTextField jtfMonto = new JTextField(10);
        jtfMonto.setBackground(Colores.verdeClaro);
        jtfMonto.setForeground(Color.WHITE);
        jtfMonto.setFont(new Font("SansSerif", Font.PLAIN, 15));

        JButton btnMonto = new JButton("Registrar");
        btnMonto.setBackground(Colores.verdeV);
        btnMonto.setForeground(Color.WHITE);
        btnMonto.setFont(new Font("SansSerif", Font.BOLD, 15));
        btnMonto.setFocusPainted(false);
        btnMonto.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));

        this.add(lblMonto);
        this.add(jtfMonto);
        this.add(btnMonto);

        btnMonto.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int monto = Integer.parseInt(jtfMonto.getText());
                    Logica.arreglo.add(new Montos(monto));
                    // agrega el monto a la tabla
                    modelo.addRow(new Object[]{"", monto});
                    JOptionPane.showMessageDialog(aviso, "INGRESADO CORRECTAMENTE!");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(aviso, "Ingrese un número válido.");
                }
            }
        });
    }
}