package barra;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class vtnPrincipal extends JFrame {

	
    public vtnPrincipal() {
        this.setTitle("Biblioteca");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(900, 500);
        this.setLocationRelativeTo(null);

        Color cPizq = Color.decode("#009282");
        Color cTitBarra = Color.decode("#8f643e");

        JPanel pIzq = new JPanel();
        pIzq.setLayout(new BorderLayout());
        pIzq.setBackground(cPizq);
        pIzq.setPreferredSize(new Dimension(180, 0));
        JPanel pTituloIzq = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pTituloIzq.setOpaque(false);
        ImageIcon im = new ImageIcon("Logo2.png");
        JLabel lbnLogo = new JLabel(new ImageIcon(im.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH)));
        JLabel titulo = new JLabel("Biblioteca");
        titulo.setForeground(Color.WHITE);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 20));
        pTituloIzq.add(lbnLogo);
        pTituloIzq.add(titulo);
        pIzq.add(pTituloIzq, BorderLayout.NORTH);
        JPanel jpMenu = new JPanel();
        jpMenu.setOpaque(false);
        jpMenu.setLayout(new BoxLayout(jpMenu, BoxLayout.Y_AXIS));
        JButton btnInicio = new JButton("Inicio", imagen("inicio.png"));
        JButton btnLibros = new JButton("Libros", imagen("libro.png"));
        JButton btnPrestamos = new JButton("Prestamos", imagen("prestamo.png"));
        JButton btnPersonas = new JButton("Personas", imagen("persona.png"));
        JButton btnCompus = new JButton("Compus", imagen("computadora.png"));
        JButton btnDinero = new JButton("Dinero", imagen("dinero.png"));
        jpMenu.add(Box.createVerticalStrut(15));
        jpMenu.add(btnInicio); Botones(btnInicio);
        jpMenu.add(Box.createVerticalStrut(10));
        jpMenu.add(btnLibros); Botones(btnLibros);
        jpMenu.add(Box.createVerticalStrut(10));
        jpMenu.add(btnPrestamos); Botones(btnPrestamos);
        jpMenu.add(Box.createVerticalStrut(10));
        jpMenu.add(btnPersonas); Botones(btnPersonas);
        jpMenu.add(Box.createVerticalStrut(10));
        jpMenu.add(btnCompus); Botones(btnCompus);
        jpMenu.add(Box.createVerticalStrut(10));
        jpMenu.add(btnDinero); Botones(btnDinero);
        pIzq.add(jpMenu, BorderLayout.CENTER);

        JPanel panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.add(pIzq, BorderLayout.WEST);
        JPanel panelContenido = new JPanel(new BorderLayout());
        panelContenido.setBackground(Colores.gris);
        panelPrincipal.add(panelContenido, BorderLayout.CENTER);
        this.setContentPane(panelPrincipal);

        mostrarPanelInicio(panelContenido);

        
        btnInicio.addActionListener(e -> mostrarPanelInicio(panelContenido));
        btnLibros.addActionListener(e -> mostrarPanelLibros(panelContenido));
        btnPrestamos.addActionListener(e -> mostrarPanelGenerico(panelContenido, "Prestamos"));
        btnPersonas.addActionListener(e -> mostrarPanelGenerico(panelContenido, "Personas"));
        btnCompus.addActionListener(e -> mostrarPanelGenerico(panelContenido, "Compus"));
        btnDinero.addActionListener(e -> mostrarPanelGenerico(panelContenido, "Dinero"));
    }

    private void Botones(JButton btn) {
        btn.setFont(new Font("SansSerif", Font.BOLD, 14)); 
        btn.setForeground(Color.WHITE);                    
        btn.setBackground(Colores.verdeOcuro);             
        btn.setBorderPainted(false); 
        btn.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10)); 
        btn.setMaximumSize(new Dimension(150,35));
        btn.setFocusable(false);

    }

    // Funcion imagenes
    private ImageIcon imagen(String imagen) {
        ImageIcon icon = new ImageIcon(imagen);
        Image img = icon.getImage().getScaledInstance(22, 22, Image.SCALE_SMOOTH);
        return new ImageIcon(img);
    }
    
    private JPanel universalBarra() {
        JPanel barraBusqueda = new JPanel();
        barraBusqueda.setLayout(new BoxLayout(barraBusqueda, BoxLayout.X_AXIS));
        barraBusqueda.setBackground(new Color(0,0,0,0));
        barraBusqueda.setOpaque(false);
        barraBusqueda.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));

        JPanel fondo = new JPanel();
        fondo.setLayout(new BoxLayout(fondo, BoxLayout.X_AXIS));
        fondo.setBackground(Color.WHITE);
        fondo.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(0,0,0,0), 0),
            BorderFactory.createEmptyBorder(5, 20, 5, 10)));
        fondo.setOpaque(true);
        fondo.setMaximumSize(new Dimension(500, 40));
        fondo.setPreferredSize(new Dimension(500, 40));
        fondo.setBorder(new javax.swing.border.EmptyBorder(5, 20, 5, 10) {
            @Override
            public boolean isBorderOpaque() { return false; }
        });

        JTextField txtBuscar = new JTextField();
        txtBuscar.setFont(new Font("SansSerif", Font.PLAIN, 16));
        txtBuscar.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        txtBuscar.setBackground(Color.WHITE);
        txtBuscar.setMaximumSize(new Dimension(350, 30));
        txtBuscar.setPreferredSize(new Dimension(350, 30));
        txtBuscar.setAlignmentY(Component.CENTER_ALIGNMENT);
        txtBuscar.setToolTipText("Buscar...");
        fondo.add(txtBuscar);

        JButton btnBuscar = new JButton();
        btnBuscar.setIcon(imagen("lupa.png"));
        btnBuscar.setBackground(Color.WHITE);
        btnBuscar.setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
        btnBuscar.setFocusPainted(false);
        btnBuscar.setAlignmentY(Component.CENTER_ALIGNMENT);
        fondo.add(btnBuscar);

        barraBusqueda.add(Box.createHorizontalGlue());
        barraBusqueda.add(fondo);
        barraBusqueda.add(Box.createRigidArea(new Dimension(10, 0)));

        barraBusqueda.add(botonAccion("V", Colores.marron));
        barraBusqueda.add(Box.createRigidArea(new Dimension(8, 0)));
        barraBusqueda.add(botonAccion("+", Colores.marron));
        barraBusqueda.add(Box.createRigidArea(new Dimension(8, 0)));
        barraBusqueda.add(botonAccionIcono("lapiz.png", Colores.marron));
        barraBusqueda.add(Box.createRigidArea(new Dimension(8, 0)));
        barraBusqueda.add(botonAccionIcono("basura.png", Colores.marron));
        barraBusqueda.add(Box.createHorizontalGlue());

        barraBusqueda.setMaximumSize(new Dimension(700, 50));
        barraBusqueda.setPreferredSize(new Dimension(700, 50));
        return barraBusqueda;
    }

    private JButton botonAccion(String txt, Color color) {
        JButton btn = new JButton(txt);
        btn.setFont(new Font("SansSerif", Font.BOLD, 18));
        btn.setForeground(color);
        btn.setBackground(Color.WHITE);
        btn.setBorder(BorderFactory.createLineBorder(new Color(0,0,0,0), 1, true));
        btn.setFocusPainted(false);
        btn.setPreferredSize(new Dimension(40, 40));
        btn.setMaximumSize(new Dimension(40, 40));
        return btn;
    }
    private JButton botonAccionIcono(String icon, Color color) {
        JButton btn = new JButton();
        btn.setIcon(imagen(icon));
        btn.setBackground(Color.WHITE);
        btn.setBorder(BorderFactory.createLineBorder(new Color(0,0,0,0), 1, true));
        btn.setFocusPainted(false);
        btn.setPreferredSize(new Dimension(40, 40));
        btn.setMaximumSize(new Dimension(40, 40));
        return btn;
    }
    
    private void mostrarPanelInicio(JPanel panelContenido) {
        panelContenido.removeAll();
        JPanel panelInicio = new JPanel();
        panelInicio.setLayout(new BoxLayout(panelInicio, BoxLayout.Y_AXIS));
        panelInicio.setBackground(Colores.gris);
        JPanel pSup = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 15));
        pSup.setBackground(Color.WHITE);
        pSup.setMaximumSize(new Dimension(900, 60));
        JLabel lbl = new JLabel("Inicio");
        lbl.setFont(new Font("SansSerif", Font.BOLD, 32));
        lbl.setForeground(Colores.marron);
        pSup.add(lbl);
        panelInicio.add(pSup);
        panelInicio.add(Box.createVerticalGlue());
        panelContenido.add(panelInicio, BorderLayout.CENTER);
        panelContenido.revalidate();
        panelContenido.repaint();
    }

    private void mostrarPanelLibros(JPanel panelContenido) {
        panelContenido.removeAll();
        JPanel panelLibros = new JPanel();
        panelLibros.setLayout(new BoxLayout(panelLibros, BoxLayout.Y_AXIS));
        panelLibros.setBackground(Colores.gris);
        JPanel pSup = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 15));
        pSup.setBackground(Color.WHITE);
        pSup.setMaximumSize(new Dimension(900, 60));
        JLabel lblTitInicio = new JLabel("Libros");
        lblTitInicio.setFont(new Font("SansSerif", Font.BOLD, 32));
        lblTitInicio.setForeground(Colores.marron);
        pSup.add(lblTitInicio);
        panelLibros.add(pSup);
        JPanel barra = universalBarra();
        JPanel barraCont = new JPanel();
        barraCont.setBackground(Colores.gris);
        barraCont.setLayout(new BoxLayout(barraCont, BoxLayout.X_AXIS));
        barraCont.setMaximumSize(new Dimension(900, 60));
        barraCont.add(Box.createHorizontalGlue());
        barraCont.add(barra);
        barraCont.add(Box.createHorizontalGlue());
        panelLibros.add(Box.createRigidArea(new Dimension(0, 30)));
        panelLibros.add(barraCont);
        panelLibros.add(Box.createVerticalGlue());
        panelContenido.add(panelLibros, BorderLayout.CENTER);
        panelContenido.revalidate();
        panelContenido.repaint();
    }

    private void mostrarPanelGenerico(JPanel panelContenido, String tituloPanel) {
        panelContenido.removeAll();
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(Colores.gris);
        JPanel pSup = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 15));
        pSup.setBackground(Color.WHITE);
        pSup.setMaximumSize(new Dimension(900, 60));
        JLabel lbl = new JLabel(tituloPanel);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 32));
        lbl.setForeground(Colores.marron);
        pSup.add(lbl);
        panel.add(pSup);
        JPanel barra = universalBarra();
        JPanel barraCont = new JPanel();
        barraCont.setBackground(Colores.gris);
        barraCont.setLayout(new BoxLayout(barraCont, BoxLayout.X_AXIS));
        barraCont.setMaximumSize(new Dimension(900, 60));
        barraCont.add(Box.createHorizontalGlue());
        barraCont.add(barra);
        barraCont.add(Box.createHorizontalGlue());
        panel.add(Box.createRigidArea(new Dimension(0, 30)));
        panel.add(barraCont);
        panel.add(Box.createVerticalGlue());
        panelContenido.add(panel, BorderLayout.CENTER);
        panelContenido.revalidate();
        panelContenido.repaint();
    }

    private JMenuBar barraMenuClasica() {
        JMenuBar barra = new JMenuBar();
        JMenu menuArchivo = new JMenu("Archivo");
        JMenuItem itemSalir = new JMenuItem("Salir");
        itemSalir.addActionListener(e -> System.exit(0));
        menuArchivo.add(itemSalir);
        JMenu menuEdicion = new JMenu("Edición");
        JMenu menuVer = new JMenu("Ver");
        JMenu menuAyuda = new JMenu("Ayuda");
        barra.add(menuArchivo);
        barra.add(menuEdicion);
        barra.add(menuVer);
        barra.add(menuAyuda);
        return barra;
    }
}