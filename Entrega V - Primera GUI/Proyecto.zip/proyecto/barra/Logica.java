package barra;

public class Logica {
    public void mostrarVentana() {
        vtnPrincipal ventana = new vtnPrincipal();
        ventana.setVisible(true);
    }
}
