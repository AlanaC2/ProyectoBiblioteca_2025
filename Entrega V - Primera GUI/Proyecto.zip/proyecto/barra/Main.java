package barra;

public class Main {
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> {
            Logica logica = new Logica();
            logica.mostrarVentana();
        });
    }
}
