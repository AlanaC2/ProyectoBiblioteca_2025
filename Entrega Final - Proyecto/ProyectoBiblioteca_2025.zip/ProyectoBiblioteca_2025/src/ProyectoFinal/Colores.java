package ProyectoFinal;

import java.awt.Color;

public class Colores {
	
	public static Color verdeOcuro = Color.decode("#04676d");
    public static Color verdeV = Color.decode("#507a3e");
    public static Color gris = Color.decode("#dadada");
    public static Color verdeClaro = Color.decode("#009282");
    public static Color marron = Color.decode("#8f643e");
    public static Color tit = Color.decode("#008273");
    public static Color retrasado = Color.decode("#ff6161");
    public static Color devuelto = Color.decode("#b8ff8c");
    public static Color prestado = Color.decode("#faf25f");



}
