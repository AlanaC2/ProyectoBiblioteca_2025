package ProyectoFinal;

import java.awt.Color;

public class Colores {
	
	public static Color verdeOcuro = Color.decode("#04676d");
    public static Color verdeV = Color.decode("#507a3e");
    public static Color gris = Color.decode("#dadada");
    public static Color verdeClaro = Color.decode("#009282");
    public static Color marron = Color.decode("#8f643e");

}
