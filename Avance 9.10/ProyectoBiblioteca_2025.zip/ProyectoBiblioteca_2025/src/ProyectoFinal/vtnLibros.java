package ProyectoFinal;

import javax.swing.JFrame;

public class vtnLibros extends JFrame{

	public vtnLibros() {
		this.setTitle("Biblioteca");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(900, 500);
        this.setLocationRelativeTo(null); 
	}
	
}
