package ProyectoFinal;

public class Compu {

	
	int Computadora;
	
	public Compu(int Computadora) {
		super();
		
		this.Computadora = Computadora;
	}

	public int getComputadora() {
		return Computadora;
	}

	public void setComputadora(int computadora) {
		Computadora = computadora;
	}

	
	
}
